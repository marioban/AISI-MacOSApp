package com.bezkoder.spring.thymeleaf.pagination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootThymeleafPaginationApplicationTests {

	@Test
	void contextLoads() {
	}

}
